#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_multi_personas.py — 从《庆余年》原文中自动识别说话人并提炼多角色微调数据集

核心思路:
  1. 将原文切分为句子级单元 (。！？ 及本书常用的 . 句点)
  2. 用通用中文小说发言归因引擎自动识别说话人 (支持「XX说道：「…」」等多种句式)
  3. 命中目标角色时: 上一句有效上下文 → user，当前句 → assistant
  4. 按角色独立 shuffle 后 8:2 写入 data/{persona_id}/train.jsonl & valid.jsonl

用法:
    python extract_multi_personas.py
    python extract_multi_personas.py --source /path/to/庆余年.txt --seed 42
"""

from __future__ import annotations

import argparse
import json
import random
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

# ---------------------------------------------------------------------------
# 1. 角色配置字典 (Persona Config)
# ---------------------------------------------------------------------------
PERSONA_CONFIG: dict[str, dict] = {
    "fanxian": {
        "name": "范闲",
        "aliases": ("范闲",),
        "system_prompt": (
            "你现在是《庆余年》中的主角范闲。你表面看似慵懒散漫、玩世不恭、"
            "毒舌爱吐槽，但内心极为重情重义、极其护短、深藏现代人的平等思想与狐狸般的机敏。"
        ),
    },
    "chenpingping": {
        "name": "陈萍萍",
        "aliases": ("陈萍萍", "老跛子", "院长"),  # 「院长」仅在轮椅/鉴查院语境下启用
        "system_prompt": (
            "你现在是《庆余年》中的鉴查院院长陈萍萍。你常年坐在轮椅上，"
            "外表看似枯槁阴冷、行事毒辣无情、说话慢条斯理且深不可测，"
            "但你将毕生的温情与谋划都留给了叶轻眉与范闲。"
        ),
    },
    "qingdi": {
        "name": "庆帝",
        "aliases": ("庆帝", "皇帝", "陛下"),
        "system_prompt": (
            "你现在是《庆余年》中的至高统治者庆帝。你极其擅长隐藏锋芒，"
            "平日里常穿一身宽松白袍、懒散地摆弄箭枝，"
            "但你骨子里是极度冷酷、掌控欲极强、深谋远虑的千古枭雄。"
        ),
    },
    "wangqinian": {
        "name": "王启年",
        "aliases": ("王启年",),
        "system_prompt": (
            "你现在是《庆余年》中的王启年。你追踪术天下无双，"
            "表面上是一个极度贪财、惧内（怕老婆）、满嘴谄媚奉承的市井小人物，"
            "但实际上你是个绝对忠诚、精明圆滑、极有生存智慧的追踪专家。"
        ),
    },
}

DEFAULT_SOURCE = Path("/Users/cassini/Downloads/庆余年.txt")
DEFAULT_OUTPUT_ROOT = Path(__file__).resolve().parent / "data"

CHAPTER_PATTERN = re.compile(
    r"^\s*第[一二三四五六七八九十百千零〇两\d]+[章节回卷部篇]\s*$"
)

# 发言动词 (长匹配优先)
SPEECH_VERB_CORE = (
    r"说道|问道|答道|应道|回道|接道|补道|解释道|斥道|"
    r"喊道|叫道|喝道|开口道|开口说|开口|继续道|继续|"
    r"冷笑道|冷哼道|微笑道|笑道|苦笑道|叹道|叹息道|"
    r"沉声道|轻声道|缓缓道|淡淡道|平静道|微微道|和声道|寒声道|温声道|"
    r"摇头道|皱眉道|"
    r"说|问|答|应|回|喊|叫|喝|道"
)

# 汉字名边界 (避免「X范闲」误切)
NAME_BOUNDARY_CHARS = set("范陈老庆皇帝陛王启年萍子跛院")

# 修饰段中的误匹配片段 (叙事描写，非发言归因)
BAD_MODIFIER_FRAGMENTS = (
    "知道", "来说", "认为", "觉得", "心想", "心里", "心头", "眼中", "手上", "身上",
    "旁边", "身边", "面前", "身后", "说话", "道谢", "道路", "通道", "报道", "味道",
    "听到", "看见", "对着", "向着",
    "关于", "至于", "属于", "并不", "却是", "只是", "不过", "于是", "因此", "所以",
    "如果", "虽然", "但是", "而且", "并且", "或者", "并非", "何以", "为何", "如何",
    "怎么", "已经", "正在", "忽然间", "一时间", "一个", "两位", "三人", "众人",
    "他们", "她们", "我们", "留在", "走在", "坐在", "站在", "倒在", "爬在", "缩在",
)

# 修饰段中含这些字 → 更可能是神态/语气描写 (发言归因)
SPEECH_MODIFIER_HINTS = set(
    "笑叹冷微淡轻沉缓慢低高怒苦愁悲喜惊诧怪感哼呵嗯哦啊呀哎唉咦嘿喂呸切嘶"
    "倒开口继续又还只便也却再先后终忽突忍不摇头皱眉好奇平静温和冷漠直接"
    "低声高声和声解释询问低头沉默片刻想了想皱着眉头一字一句压低声音忽然"
    "开口自嘲笑骂斥寒天真接补附和颤声愁苦"
)

# 本书使用的引号字符 (含弯引号 “ ” 与直角引号 「)
QUOTE_CHARS = '""「\u201c\u201d'

# 名字后直接冒号接引号: 范闲沉声说道：「……」
COLON_QUOTE_RE = re.compile(rf"[^，。！？\n]{{0,35}}[：][{QUOTE_CHARS}]")

# 带标点结尾的归因正则 (捕获标点以便检查后续引号)
ATTRIBUTION_RE = re.compile(
    rf"(?P<mod>[^，。：！？\n{QUOTE_CHARS}]{{0,28}}?)"
    rf"(?P<verb>{SPEECH_VERB_CORE})(?P<punct>[，：])"
)

# 引号开头标记
QUOTE_START_RE = re.compile(rf"^[{QUOTE_CHARS}]")

# 构建别名 → persona_id 反向索引 (长名优先)
ALIAS_TO_PERSONA: dict[str, str] = {}
for pid, cfg in PERSONA_CONFIG.items():
    for alias in cfg["aliases"]:
        ALIAS_TO_PERSONA[alias] = pid
SORTED_ALIASES = sorted(ALIAS_TO_PERSONA.keys(), key=len, reverse=True)


def read_novel(path: Path) -> str:
    """按常见中文电子书编码顺序读取全文。"""
    for encoding in ("gbk", "gb18030", "utf-8"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue
    return path.read_text(encoding="gbk", errors="replace")


def clean_text(text: str) -> str:
    """合并连续空白为单空格并去首尾空白。"""
    return re.sub(r"[\s\u3000]+", " ", text).strip()


def is_chapter_title(text: str) -> bool:
    stripped = text.strip()
    if CHAPTER_PATTERN.match(stripped):
        return True
    if len(stripped) < 20 and re.match(r"^楔子\s", stripped):
        return True
    return False


def is_valid_unit(text: str, min_len: int = 6) -> bool:
    """有效上下文/句子: 足够长、非章节标题。"""
    cleaned = clean_text(text)
    if len(cleaned) < min_len:
        return False
    if is_chapter_title(cleaned):
        return False
    if re.fullmatch(r"[\s…\.·—\-=]+", cleaned):
        return False
    return True


def _is_compound_verb(verb: str) -> bool:
    """复合发言动词 (如 应道/冷笑道)，比单字「道」更可信。"""
    return len(verb) > 1 and verb not in ("开口", "继续")


def _attribution_has_dialogue(rest: str, match_end: int, punct: str) -> bool:
    """归因后是否紧跟引号，或使用了冒号 (典型对话标记)。"""
    tail = rest[match_end:]
    if punct == "：":
        return True
    return bool(QUOTE_START_RE.match(tail))


def _try_attribution(alias: str, rest: str) -> bool:
    """检测「名字 + 修饰 + 动词 + 标点」式发言归因。"""
    match = ATTRIBUTION_RE.match(rest)
    if not match:
        return False

    mod = match.group("mod")
    verb = match.group("verb")
    punct = match.group("punct")
    full = mod + verb

    if any(frag in full for frag in BAD_MODIFIER_FRAGMENTS):
        return False
    if verb == "道" and mod.endswith("知"):
        return False
    if alias == "范闲" and mod in ("来", "去"):
        return False

    has_dialogue = _attribution_has_dialogue(rest, match.end(), punct)

    # 范闲说道
    if mod == "说" and verb == "道":
        return True

    # 复合动词: 应道 / 冷笑道 / 平静说道 等
    if _is_compound_verb(verb):
        return has_dialogue or punct == "："

    # 交互动词
    if verb in ("问", "答", "应", "回", "喊", "叫", "喝"):
        return has_dialogue or punct == "："

    # 无修饰的 说/道 → 必须有引号或冒号
    if not mod and verb in ("说", "道"):
        return has_dialogue

    # 含神态修饰
    if mod and any(ch in mod for ch in SPEECH_MODIFIER_HINTS):
        return has_dialogue or punct == "：" or verb != "道"

    return False


def _try_colon_quote(alias: str, rest: str) -> bool:
    """检测「名字 + …… + ： + 引号」式发言。"""
    match = COLON_QUOTE_RE.match(rest)
    if not match:
        return False
    prefix = rest[: match.end() - 1]
    # 纯叙事神态 (非发言): 范闲想着……：「
    if any(frag in prefix for frag in ("想着", "如是想", "知道", "认为", "觉得")):
        return False
    return True


def detect_speaker(sentence: str) -> str | None:
    """
    自动解析句子中的说话人，返回 persona_id。
    支持:
      - 范闲平静说道：「……」
      - 范闲应道：「……」
      - 范闲冷笑道，「……」
    """
    best_pos = len(sentence) + 1
    best_persona: str | None = None

    for alias in SORTED_ALIASES:
        start = 0
        while True:
            pos = sentence.find(alias, start)
            if pos == -1:
                break

            if pos > 0 and sentence[pos - 1] in NAME_BOUNDARY_CHARS:
                start = pos + 1
                continue

            rest = sentence[pos + len(alias) :]
            matched = _try_colon_quote(alias, rest) or _try_attribution(alias, rest)
            if not matched:
                start = pos + 1
                continue

            persona = ALIAS_TO_PERSONA[alias]

            # 「院长」需鉴查院语境
            if alias == "院长":
                ctx = sentence[max(0, pos - 12) : pos + len(alias) + 20]
                if not any(k in ctx for k in ("陈萍萍", "老跛子", "轮椅", "鉴查", "监察")):
                    start = pos + 1
                    continue

            if pos < best_pos:
                best_pos = pos
                best_persona = persona

            start = pos + 1

    return best_persona


def split_into_units(text: str) -> list[str]:
    """
    切分为句子级单元:
    - 中文句号 。！？ 与部分章节使用的英文句点 . 均作为分句边界
    - 跳过章节标题
    """
    units: list[str] = []

    for block in re.split(r"\n\s*\n+", text):
        block = clean_text(block)
        if not block or is_chapter_title(block):
            continue

        for chunk in re.split(r"(?<=[。！？])", block):
            chunk = chunk.strip()
            if not chunk:
                continue
            # 本书部分章节用 `.` 作句点
            for sent in re.split(r"(?<=\.)", chunk):
                sent = clean_text(sent)
                if is_valid_unit(sent):
                    units.append(sent)

    return units


def extract_all_dialogues(units: list[str]) -> dict[str, list[dict]]:
    """
    扫描句子序列，自动识别说话人并构建各角色样本列表。
    user = 上一有效单元; assistant = 当前发言句
    """
    buckets: dict[str, list[dict]] = defaultdict(list)
    last_context: str | None = None

    for unit in units:
        persona_id = detect_speaker(unit)

        if persona_id is None:
            last_context = unit
            continue

        if last_context and last_context != unit:
            buckets[persona_id].append(
                {
                    "messages": [
                        {"role": "system", "content": PERSONA_CONFIG[persona_id]["system_prompt"]},
                        {"role": "user", "content": last_context},
                        {"role": "assistant", "content": unit},
                    ]
                }
            )

        last_context = unit

    return buckets


def deduplicate_samples(samples: list[dict]) -> list[dict]:
    """按 (user, assistant) 内容去重，保留首次出现。"""
    seen: set[tuple[str, str]] = set()
    unique: list[dict] = []
    for sample in samples:
        msgs = sample["messages"]
        key = (msgs[1]["content"], msgs[2]["content"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(sample)
    return unique


def write_jsonl(path: Path, records: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def split_and_export(
    samples: list[dict],
    persona_id: str,
    output_root: Path,
    train_ratio: float = 0.8,
    seed: int = 42,
) -> tuple[int, int]:
    shuffled = samples.copy()
    rng = random.Random(seed + hash(persona_id) % 10000)
    rng.shuffle(shuffled)

    if not shuffled:
        write_jsonl(output_root / persona_id / "train.jsonl", [])
        write_jsonl(output_root / persona_id / "valid.jsonl", [])
        return 0, 0

    split_idx = max(1, int(len(shuffled) * train_ratio))
    if len(shuffled) >= 2 and split_idx == len(shuffled):
        split_idx = len(shuffled) - 1

    persona_dir = output_root / persona_id
    write_jsonl(persona_dir / "train.jsonl", shuffled[:split_idx])
    write_jsonl(persona_dir / "valid.jsonl", shuffled[split_idx:])
    return split_idx, len(shuffled) - split_idx


def print_stats_table(rows: list[tuple[str, str, int, int, int]]) -> None:
    headers = ("角色 ID", "角色名", "总条数", "train", "valid")
    col_widths = [max(len(h), *(len(str(r[i])) for r in rows)) + 2 for i, h in enumerate(headers)]

    def fmt_row(cells: tuple) -> str:
        return "".join(str(c).ljust(col_widths[i]) for i, c in enumerate(cells))

    sep = "-" * sum(col_widths)
    print("\n" + sep)
    print(fmt_row(headers))
    print(sep)
    total = 0
    for row in rows:
        print(fmt_row(row))
        total += row[2]
    print(sep)
    print(f"{'合计'.ljust(col_widths[0])}{''.ljust(col_widths[1])}{str(total).ljust(col_widths[2])}")
    print(sep + "\n")


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="从《庆余年》原文自动识别说话人并提炼多角色微调 JSONL 数据集"
    )
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--train-ratio", type=float, default=0.8)
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)

    if not args.source.is_file():
        print(f"[错误] 找不到原文文件: {args.source}", file=sys.stderr)
        return 1

    print(f"正在读取: {args.source}")
    novel_text = read_novel(args.source)
    units = split_into_units(novel_text)
    print(f"共解析 {len(units):,} 个句子/段落单元")
    print("正在自动识别说话人并提取对话…\n")

    buckets = extract_all_dialogues(units)
    stats_rows: list[tuple[str, str, int, int, int]] = []

    for persona_id, config in PERSONA_CONFIG.items():
        samples = deduplicate_samples(buckets.get(persona_id, []))
        train_n, valid_n = split_and_export(
            samples, persona_id, args.output, args.train_ratio, args.seed
        )
        total = train_n + valid_n
        stats_rows.append((persona_id, config["name"], total, train_n, valid_n))
        print(f"  ✓ {config['name']:>4s} ({persona_id}) → {args.output / persona_id}/  [{total} 条]")

    print_stats_table(stats_rows)
    print(f"数据已写入: {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
