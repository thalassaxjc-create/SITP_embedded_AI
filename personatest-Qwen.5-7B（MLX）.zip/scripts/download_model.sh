#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOCAL_MODEL="$ROOT/models/Qwen2.5-7B-Instruct-4bit"
REPO="${MODEL:-mlx-community/Qwen2.5-7B-Instruct-4bit}"

echo ">>> 通过 hf-mirror 下载基座模型"
echo ">>> 仓库: $REPO"
echo ">>> 目标: $LOCAL_MODEL"
echo ">>> 大文件完整下载（不支持续传，请勿中断），每 2 秒显示进度"
echo ""

export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"

python3 "$ROOT/scripts/download_model.py" --repo "$REPO" --dest "$LOCAL_MODEL"

echo ""
echo ">>> 验证模型文件..."
if [[ ! -f "$LOCAL_MODEL/model.safetensors" ]]; then
  echo "缺少 model.safetensors，下载未完成。"
  exit 1
fi

WEIGHT_MB=$(( $(stat -f%z "$LOCAL_MODEL/model.safetensors" 2>/dev/null || stat -c%s "$LOCAL_MODEL/model.safetensors") / 1024 / 1024 ))
echo ">>> model.safetensors: ${WEIGHT_MB} MB"

if command -v mlx_lm.generate >/dev/null 2>&1; then
  echo ">>> 快速加载测试..."
  mlx_lm.generate --model "$LOCAL_MODEL" --prompt "ping" --max-tokens 1
fi

echo ""
echo ">>> 模型已就绪"
echo ">>> 启动服务: ./scripts/serve.sh base"
