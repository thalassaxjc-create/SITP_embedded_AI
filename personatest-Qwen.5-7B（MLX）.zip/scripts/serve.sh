#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PERSONALITY="${1:-base}"
PORT="${2:-8080}"
LOCAL_MODEL="$ROOT/models/Qwen2.5-7B-Instruct-4bit"

if [[ -d "$LOCAL_MODEL" && -f "$LOCAL_MODEL/config.json" ]]; then
  MODEL="${MODEL:-$LOCAL_MODEL}"
else
  MODEL="${MODEL:-mlx-community/Qwen2.5-7B-Instruct-4bit}"
  export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
fi

if [[ "$MODEL" == "$LOCAL_MODEL" || "$MODEL" == "$ROOT/models/"* ]]; then
  if ! "$ROOT/scripts/verify_model.sh"; then
    exit 1
  fi
fi

cd "$ROOT"

ARGS=(--model "$MODEL" --port "$PORT" --host 127.0.0.1)

if [[ "$PERSONALITY" != "base" ]]; then
  ADAPTER_DIR="$ROOT/adapters/$PERSONALITY"
  if [[ ! -d "$ADAPTER_DIR" ]]; then
    echo "找不到 adapter: $ADAPTER_DIR"
    echo "请先运行: ./scripts/train.sh $PERSONALITY"
    exit 1
  fi
  ARGS+=(--adapter-path "$ADAPTER_DIR")
  echo ">>> 启动人格: $PERSONALITY"
else
  echo ">>> 启动基座模型（无人格 adapter）"
fi

echo ">>> 模型路径: $MODEL"
echo ">>> API 地址: http://localhost:$PORT/v1"
echo ">>> 按 Ctrl+C 停止服务"
echo ""

"$ROOT/scripts/free_port.sh" "$PORT"

mlx_lm.server "${ARGS[@]}"
