#!/usr/bin/env bash
set -euo pipefail

PORT="${1:-8080}"
BASE="http://localhost:$PORT"

echo ">>> 检查服务: $BASE/v1/models"
curl -sf "$BASE/v1/models" -H "Content-Type: application/json" | python3 -m json.tool

echo ""
echo ">>> 测试对话: $BASE/v1/chat/completions"
MODEL_ID="$(curl -sf "$BASE/v1/models" | python3 -c "import sys, json; print(json.load(sys.stdin)['data'][0]['id'])")"
curl -sf "$BASE/v1/chat/completions" \
  -H "Content-Type: application/json" \
  -d "{
    \"model\": $(python3 -c "import json; print(json.dumps('$MODEL_ID'))"),
    \"messages\": [{\"role\": \"user\", \"content\": \"用一句话介绍你自己\"}],
    \"max_tokens\": 128,
    \"temperature\": 0.7
  }" | python3 -m json.tool
