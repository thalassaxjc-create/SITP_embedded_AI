#!/usr/bin/env bash
# 一键启动：自动释放 8080/3000，后台 MLX + 前台 Web。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PERSONALITY="${1:-base}"
API_PORT="${API_PORT:-8080}"
WEB_PORT="${WEB_PORT:-3000}"

"$ROOT/scripts/free_port.sh" "$API_PORT"
"$ROOT/scripts/free_port.sh" "$WEB_PORT"

export WEB_PORT API_URL="http://127.0.0.1:${API_PORT}"

echo ">>> 启动 MLX 服务 (端口 ${API_PORT})..."
"$ROOT/scripts/serve.sh" "$PERSONALITY" "$API_PORT" &
SERVE_PID=$!

cleanup() {
  kill "$SERVE_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

sleep 2
echo ">>> 启动 Web 前端 (端口 ${WEB_PORT})..."
exec "$ROOT/scripts/web.sh"
