#!/usr/bin/env bash
# 释放指定 TCP 端口（macOS / Linux）。被 web.sh、serve.sh 调用，避免 Address already in use。
set -euo pipefail

PORT="${1:?用法: free_port.sh <端口号>}"

pids() {
  lsof -ti "tcp:${PORT}" -sTCP:LISTEN 2>/dev/null || true
}

existing="$(pids)"
if [[ -z "$existing" ]]; then
  exit 0
fi

echo ">>> 端口 ${PORT} 已被占用 (PID: ${existing//$'\n'/ })，正在释放..."

kill $existing 2>/dev/null || true
sleep 1

remaining="$(pids)"
if [[ -n "$remaining" ]]; then
  kill -9 $remaining 2>/dev/null || true
  sleep 0.5
fi

if [[ -n "$(pids)" ]]; then
  echo ">>> 无法释放端口 ${PORT}，请手动检查: lsof -i :${PORT}" >&2
  exit 1
fi

echo ">>> 端口 ${PORT} 已就绪"
