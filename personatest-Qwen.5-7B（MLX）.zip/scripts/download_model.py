#!/usr/bin/env python3
"""通过 hf-mirror 下载 MLX 模型（不依赖 huggingface_hub）。"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
from pathlib import Path

MIRROR = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com").rstrip("/")
DEFAULT_REPO = "mlx-community/Qwen2.5-7B-Instruct-4bit"
MIN_WEIGHT_BYTES = 1024 * 1024 * 1024
STRICT_TOLERANCE = 8192  # 完整文件必须与 CDN 体积几乎一致

DEFAULT_FILES = [
    "config.json",
    "tokenizer_config.json",
    "tokenizer.json",
    "vocab.json",
    "merges.txt",
    "added_tokens.json",
    "special_tokens_map.json",
    "model.safetensors.index.json",
    "model.safetensors",
    "README.md",
]


def expected_weight_bytes(dest_dir: Path) -> int | None:
    index = dest_dir / "model.safetensors.index.json"
    if not index.is_file():
        return None
    try:
        data = json.loads(index.read_text())
        total = int(data.get("metadata", {}).get("total_size", 0))
        return total or None
    except (OSError, ValueError, TypeError):
        return None


def remote_weight_bytes(repo_id: str) -> int | None:
    url = f"{MIRROR}/{repo_id}/resolve/main/model.safetensors"
    cmd = ["curl", "-fsSIL", url]
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        return None
    for line in reversed(result.stdout.splitlines()):
        if line.lower().startswith("content-length:"):
            try:
                return int(line.split(":", 1)[1].strip())
            except ValueError:
                return None
    return None


def canonical_expected_bytes(repo_id: str, dest_dir: Path) -> int | None:
    return remote_weight_bytes(repo_id) or expected_weight_bytes(dest_dir)


def format_gb(num_bytes: int) -> str:
    return f"{num_bytes / (1024 ** 3):.2f} GB"


def weights_valid(
    dest: Path,
    dest_dir: Path,
    repo_id: str = DEFAULT_REPO,
) -> tuple[bool, str]:
    if not dest.is_file():
        return False, "缺少 model.safetensors"

    size = dest.stat().st_size
    expected = canonical_expected_bytes(repo_id, dest_dir)
    if expected:
        diff = abs(size - expected)
        if diff > STRICT_TOLERANCE:
            return (
                False,
                f"model.safetensors 大小异常（当前 {format_gb(size)}，"
                f"期望 {format_gb(expected)}，差 {diff / (1024 ** 2):.1f} MB）",
            )
        return True, "ok"

    if size < MIN_WEIGHT_BYTES:
        return False, f"model.safetensors 仅 {size / (1024 ** 2):.0f} MB，文件不完整"
    return True, "ok"


def list_files(repo_id: str) -> list[str]:
    try:
        os.environ.setdefault("HF_ENDPOINT", MIRROR)
        from huggingface_hub import HfApi

        api = HfApi(endpoint=MIRROR)
        info = api.model_info(repo_id)
        files = [s.rfilename for s in info.siblings if not s.rfilename.startswith(".git")]
        if files:
            return files
    except Exception:
        pass

    if repo_id != DEFAULT_REPO:
        print(f"未安装 huggingface_hub，且没有 {repo_id} 的内置文件列表。", file=sys.stderr)
        print("请安装: pip install huggingface_hub", file=sys.stderr)
        print(f"或改用默认模型: {DEFAULT_REPO}", file=sys.stderr)
        raise SystemExit(1)

    print(">>> 使用内置文件列表（无需 huggingface_hub）")
    return DEFAULT_FILES


def _progress_loop(part: Path, expected: int | None, stop: threading.Event) -> None:
    while not stop.wait(2):
        if not part.is_file():
            continue
        size = part.stat().st_size
        if expected and expected > 0:
            pct = min(100.0, size * 100 / expected)
            bar_len = 30
            filled = int(bar_len * pct / 100)
            bar = "#" * filled + "-" * (bar_len - filled)
            print(
                f"\r    [{bar}] {format_gb(size)} / {format_gb(expected)} ({pct:.1f}%)",
                end="",
                flush=True,
            )
        else:
            print(f"\r    已下载 {format_gb(size)}", end="", flush=True)
    print(flush=True)


def download_weights(repo_id: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    expected = canonical_expected_bytes(repo_id, dest.parent)

    ok, reason = weights_valid(dest, dest.parent, repo_id)
    if ok:
        print(f"  跳过（已存在且校验通过）: model.safetensors ({format_gb(dest.stat().st_size)})")
        return

    for path in (dest, part):
        if path.exists():
            print(f"  删除无效文件: {path.name} ({reason if path == dest else '重新完整下载'})")
            path.unlink()

    if not expected:
        print("  无法获取远程文件大小，仍尝试下载", file=sys.stderr)
    else:
        print(f"  下载: model.safetensors（完整下载 {format_gb(expected)}，不支持续传）")
        print("    请勿中断；中断后需重新完整下载")

    url = f"{MIRROR}/{repo_id}/resolve/main/model.safetensors"
    cmd = ["curl", "-fSL", "--retry", "5", "--retry-delay", "3", "-o", str(part), url]

    stop = threading.Event()
    progress = threading.Thread(
        target=_progress_loop,
        args=(part, expected),
        kwargs={"stop": stop},
        daemon=True,
    )
    progress.start()

    result = subprocess.run(cmd, capture_output=True, text=True)
    stop.set()
    progress.join(timeout=1)

    if result.returncode != 0:
        stderr = result.stderr.strip()
        if part.exists():
            part.unlink(missing_ok=True)
        raise RuntimeError(stderr or "curl failed for model.safetensors")

    ok, reason = weights_valid(part, dest.parent, repo_id)
    if not ok:
        part.unlink(missing_ok=True)
        raise RuntimeError(f"下载完成但校验失败: {reason}")

    part.replace(dest)
    print(f"    完成: {format_gb(dest.stat().st_size)}（校验通过）")


def download_file(repo_id: str, filename: str, dest: Path) -> None:
    if filename == "model.safetensors":
        download_weights(repo_id, dest)
        return

    if dest.exists() and dest.stat().st_size > 0:
        print(f"  跳过（已存在）: {filename}")
        return


def main() -> int:
    parser = argparse.ArgumentParser(description="从 hf-mirror 下载 MLX 模型")
    parser.add_argument("--repo", default=os.environ.get("MODEL", DEFAULT_REPO))
    parser.add_argument(
        "--dest",
        default=str(Path(__file__).resolve().parent.parent / "models" / "Qwen2.5-7B-Instruct-4bit"),
    )
    args = parser.parse_args()

    dest_dir = Path(args.dest).resolve()
    weights = dest_dir / "model.safetensors"
    expected = canonical_expected_bytes(args.repo, dest_dir)

    print(f">>> 镜像源: {MIRROR}")
    print(f">>> 模型仓库: {args.repo}")
    print(f">>> 保存目录: {dest_dir}")

    ok, _ = weights_valid(weights, dest_dir, args.repo)
    if ok:
        print(f">>> 模型已存在: {format_gb(weights.stat().st_size)}（无需下载）")
        return 0

    if expected:
        print(f">>> 权重文件 {format_gb(expected)}，完整下载，每 2 秒刷新进度")
    else:
        print(">>> 权重文件约 4GB，完整下载，每 2 秒刷新进度")
    print(">>> 注意：hf-mirror 断点续传容易损坏文件，已改为每次完整下载")
    print()

    files = list_files(args.repo)
    if "model.safetensors" in files:
        files = ["model.safetensors"] + [f for f in files if f != "model.safetensors"]

    for name in files:
        try:
            download_file(args.repo, name, dest_dir / name)
        except Exception as exc:
            print(f"\n下载失败 {name}: {exc}", file=sys.stderr)
            return 1

    ok, reason = weights_valid(weights, dest_dir, args.repo)
    if not ok:
        print(f"\n{reason}", file=sys.stderr)
        return 1

    print()
    print(">>> 下载完成")
    print(f">>> model.safetensors: {format_gb(weights.stat().st_size)}（校验通过）")
    print(f">>> 本地路径: {dest_dir}")
    print(">>> 启动服务: ./scripts/start.sh")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
