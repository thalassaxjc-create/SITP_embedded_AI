#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export WEB_PORT="${WEB_PORT:-3000}"
export API_URL="${API_URL:-http://127.0.0.1:8080}"

"$ROOT/scripts/free_port.sh" "$WEB_PORT"

cd "$ROOT/web"
exec env WEB_PORT="$WEB_PORT" API_URL="$API_URL" HF_TOKEN="${HF_TOKEN:-}" python3 server.py
