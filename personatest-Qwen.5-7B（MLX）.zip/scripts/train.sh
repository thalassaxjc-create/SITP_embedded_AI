#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PERSONALITY="${1:-}"

if [[ -z "$PERSONALITY" ]]; then
  echo "用法: ./scripts/train.sh <人格名>"
  echo "可选: normal(base) | fanxian | chenpingping | qingdi | wangqinian"
  exit 1
fi

DATA_DIR="$ROOT/data/$PERSONALITY"
ADAPTER_DIR="$ROOT/adapters/$PERSONALITY"
CONFIG="$ROOT/config/base.yaml"
LOCAL_MODEL="$ROOT/models/Qwen2.5-7B-Instruct-4bit"

if [[ -d "$LOCAL_MODEL" && -f "$LOCAL_MODEL/config.json" ]]; then
  MODEL="${MODEL:-$LOCAL_MODEL}"
else
  MODEL="${MODEL:-mlx-community/Qwen2.5-7B-Instruct-4bit}"
  export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
fi

if [[ ! -f "$DATA_DIR/train.jsonl" ]]; then
  echo "找不到训练数据: $DATA_DIR/train.jsonl"
  exit 1
fi

mkdir -p "$ADAPTER_DIR"

echo ">>> 训练人格: $PERSONALITY"
echo ">>> 数据目录: $DATA_DIR"
echo ">>> Adapter 输出: $ADAPTER_DIR"

mlx_lm.lora \
  --config "$CONFIG" \
  --model "$MODEL" \
  --train \
  --data "$DATA_DIR" \
  --adapter-path "$ADAPTER_DIR" \
  --grad-checkpoint

echo ""
echo "训练完成。Adapter 保存在: $ADAPTER_DIR"
