#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PERSONALITY="${1:-base}"
PROMPT="${2:-你好，请用你的人格风格回答我。}"
LOCAL_MODEL="$ROOT/models/Qwen2.5-7B-Instruct-4bit"

if [[ -d "$LOCAL_MODEL" && -f "$LOCAL_MODEL/config.json" ]]; then
  MODEL="${MODEL:-$LOCAL_MODEL}"
else
  MODEL="${MODEL:-mlx-community/Qwen2.5-7B-Instruct-4bit}"
  export HF_ENDPOINT="${HF_ENDPOINT:-https://hf-mirror.com}"
fi

ARGS=(--model "$MODEL" --prompt "$PROMPT" --max-tokens 256)

if [[ "$PERSONALITY" != "base" ]]; then
  ADAPTER_DIR="$ROOT/adapters/$PERSONALITY"
  ARGS+=(--adapter-path "$ADAPTER_DIR")
fi

mlx_lm.generate "${ARGS[@]}"
