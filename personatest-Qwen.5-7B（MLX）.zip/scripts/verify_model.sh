#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 - <<'PY' "$ROOT/models/Qwen2.5-7B-Instruct-4bit"
import json
import subprocess
import sys
from pathlib import Path

dest_dir = Path(sys.argv[1])
weights = dest_dir / "model.safetensors"
repo = "mlx-community/Qwen2.5-7B-Instruct-4bit"
mirror = __import__("os").environ.get("HF_ENDPOINT", "https://hf-mirror.com").rstrip("/")

if not weights.is_file():
    print(">>> 缺少 model.safetensors")
    sys.exit(1)

size = weights.stat().st_size
expected = None
proc = subprocess.run(
    ["curl", "-fsSIL", f"{mirror}/{repo}/resolve/main/model.safetensors"],
    capture_output=True,
    text=True,
)
if proc.returncode == 0:
    for line in reversed(proc.stdout.splitlines()):
        if line.lower().startswith("content-length:"):
            expected = int(line.split(":", 1)[1].strip())
            break
if expected is None:
    index = dest_dir / "model.safetensors.index.json"
    if index.is_file():
        expected = json.loads(index.read_text()).get("metadata", {}).get("total_size")

if expected and abs(size - int(expected)) > 8192:
    print(f">>> 模型文件损坏: {size / (1024 ** 3):.2f} GB，期望 {int(expected) / (1024 ** 3):.2f} GB")
    print(">>> 请运行: ./scripts/download_model.sh")
    sys.exit(1)

print(f">>> 模型文件正常: {size / (1024 ** 3):.2f} GB")

PY
