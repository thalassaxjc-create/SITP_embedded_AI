#!/usr/bin/env python3
"""静态前端 + 本地 MLX / 云端 HuggingFace 反向代理。"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.parse
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
LOCAL_MODEL = Path(
    os.environ.get(
        "LOCAL_MODEL",
        str(PROJECT_ROOT / "models" / "Qwen2.5-7B-Instruct-4bit"),
    )
)
LOCAL_API = os.environ.get("API_URL", "http://127.0.0.1:8080").rstrip("/")
MIN_WEIGHT_BYTES = 1024 * 1024 * 1024
HF_API = os.environ.get("HF_API_URL", "https://router.huggingface.co").rstrip("/")
WEB_PORT = int(os.environ.get("WEB_PORT", "3000"))
CHAT_TIMEOUT = int(os.environ.get("CHAT_TIMEOUT", "600"))
# macOS 系统代理会导致 urllib 访问 127.0.0.1 失败（502）
_NO_PROXY_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/health":
            params = urllib.parse.parse_qs(parsed.query)
            backend = params.get("backend", ["local"])[0].lower()
            if backend == "cloud":
                self._cloud_health()
            else:
                self._local_health()
            return
        if parsed.path == "/api/local-model":
            self._local_model_info()
            return
        if parsed.path.startswith("/v1/"):
            self._proxy_local("GET", parsed.path, timeout=10)
            return
        super().do_GET()

    def do_POST(self) -> None:
        if not self.path.startswith("/v1/"):
            self.send_error(404)
            return

        body = self._read_body()
        backend = self.headers.get("X-Backend", "local").lower()
        stream = False
        if body:
            try:
                stream = bool(json.loads(body).get("stream"))
            except json.JSONDecodeError:
                pass

        if backend == "cloud":
            token = self._get_hf_token()
            if not token:
                self._send_json(
                    401,
                    {
                        "error": "缺少 HF Token",
                        "detail": "请在侧边栏填入 Token，或设置环境变量 HF_TOKEN。",
                    },
                )
                return
            if stream:
                self._proxy_stream(f"{HF_API}/v1/chat/completions", body, token=token)
            else:
                self._proxy_request(
                    "POST",
                    f"{HF_API}/v1/chat/completions",
                    body=body,
                    timeout=CHAT_TIMEOUT,
                    token=token,
                )
            return

        if stream:
            self._proxy_stream(f"{LOCAL_API}{self.path}", self._resolve_local_body(body))
        else:
            self._proxy_local(
                "POST",
                self.path,
                body=self._resolve_local_body(body),
                timeout=CHAT_TIMEOUT,
            )

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self._cors_headers()
        self.end_headers()

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", 0))
        return self.rfile.read(length) if length else b""

    def _get_hf_token(self) -> str:
        header_token = self.headers.get("X-HF-Token", "").strip()
        if header_token:
            return header_token
        return os.environ.get("HF_TOKEN", "").strip()

    def _resolve_local_body(self, body: bytes | None) -> bytes | None:
        if not body:
            return body
        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            return body
        model = payload.get("model")
        if model in ("local", "default", "default_model"):
            payload["model"] = str(LOCAL_MODEL)
            return json.dumps(payload, ensure_ascii=False).encode()
        return body

    def _local_model_info(self) -> None:
        ready, detail = self._local_model_status()
        if not ready:
            self._send_json(503, {"status": "model_incomplete", "detail": detail})
            return
        self._send_json(200, {"status": "ok", "model": str(LOCAL_MODEL)})

    def _local_model_status(self) -> tuple[bool, str]:
        weights = LOCAL_MODEL / "model.safetensors"
        if weights.is_file() and weights.stat().st_size >= MIN_WEIGHT_BYTES:
            return True, "ok"

        part = LOCAL_MODEL / "model.safetensors.part"
        if part.is_file():
            done_mb = part.stat().st_size / (1024 * 1024)
            return (
                False,
                f"基座模型权重未下载完成（{done_mb:.0f} MB / 约 4000 MB）。"
                "请运行 ./scripts/download_model.sh 并等待完成。",
            )

        if (LOCAL_MODEL / "model.safetensors.index.json").is_file():
            return (
                False,
                "缺少 model.safetensors。请运行 ./scripts/download_model.sh 下载基座模型。",
            )

        return (
            False,
            "未找到本地基座模型。请先运行 ./scripts/download_model.sh。",
        )

    def _local_health(self) -> None:
        ready, detail = self._local_model_status()
        if not ready:
            self._send_json(503, {"status": "model_incomplete", "detail": detail})
            return

        self._proxy_local("GET", "/health", timeout=10)

    def _cloud_health(self) -> None:
        token = self._get_hf_token()
        if not token:
            self._send_json(
                401,
                {
                    "status": "missing_token",
                    "detail": "请填入 Hugging Face Token 或设置 HF_TOKEN 环境变量。",
                },
            )
            return
        self._send_json(
            200,
            {
                "status": "ok",
                "backend": "cloud",
                "token_source": "header" if self.headers.get("X-HF-Token", "").strip() else "env",
            },
        )

    def _proxy_local(
        self,
        method: str,
        path: str,
        body: bytes | None = None,
        timeout: int = 30,
    ) -> None:
        self._proxy_request("POST" if body else method, f"{LOCAL_API}{path}", body, timeout)

    def _proxy_request(
        self,
        method: str,
        url: str,
        body: bytes | None = None,
        timeout: int = 30,
        token: str | None = None,
    ) -> None:
        headers = {}
        if body is not None:
            headers["Content-Type"] = "application/json"
        if token:
            headers["Authorization"] = f"Bearer {token}"

        req = urllib.request.Request(url, data=body, method=method, headers=headers)

        try:
            with _NO_PROXY_OPENER.open(req, timeout=timeout) as resp:
                payload = resp.read()
                content_type = resp.headers.get("Content-Type", "application/json")
                self.send_response(resp.status)
                self.send_header("Content-Type", content_type)
                self._cors_headers()
                self.end_headers()
                self.wfile.write(payload)
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Type", exc.headers.get("Content-Type", "application/json"))
            self._cors_headers()
            self.end_headers()
            self.wfile.write(payload)
        except urllib.error.URLError as exc:
            self._send_json(502, {"error": "无法连接上游服务", "detail": str(exc.reason)})
        except TimeoutError:
            self._send_json(
                504,
                {
                    "error": "模型响应超时",
                    "detail": "请稍后重试。本地模式首次加载模型可能需要几分钟。",
                },
            )

    def _proxy_stream(self, url: str, body: bytes, token: str | None = None) -> None:
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"

        req = urllib.request.Request(url, data=body, method="POST", headers=headers)

        try:
            resp = _NO_PROXY_OPENER.open(req, timeout=CHAT_TIMEOUT)
            self.send_response(resp.status)
            content_type = resp.headers.get("Content-Type", "text/event-stream")
            self.send_header("Content-Type", content_type)
            self._cors_headers()
            self.end_headers()

            while True:
                chunk = resp.read(4096)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
        except urllib.error.HTTPError as exc:
            payload = exc.read()
            self.send_response(exc.code)
            self.send_header("Content-Type", exc.headers.get("Content-Type", "application/json"))
            self._cors_headers()
            self.end_headers()
            self.wfile.write(payload)
        except urllib.error.URLError as exc:
            self._send_json(502, {"error": "无法连接上游服务", "detail": str(exc.reason)})
        except TimeoutError:
            self._send_json(
                504,
                {
                    "error": "模型响应超时",
                    "detail": "请稍后重试。",
                },
            )

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self._cors_headers()
        self.end_headers()
        self.wfile.write(body)

    def _cors_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Content-Type, X-Backend, X-HF-Token",
        )

    def log_message(self, fmt: str, *args) -> None:
        if self.path.startswith("/v1/") or self.path.startswith("/api/health"):
            super().log_message(fmt, *args)


def main() -> None:
    try:
        server = ThreadingHTTPServer(("127.0.0.1", WEB_PORT), Handler)
    except OSError as exc:
        if exc.errno == 48:
            print(f">>> 端口 {WEB_PORT} 已被占用。")
            print(f">>> 请直接重新运行: ./scripts/web.sh")
            print(f">>> 脚本会自动释放端口；或手动: ./scripts/free_port.sh {WEB_PORT}")
            raise SystemExit(1) from exc
        raise

    print(f">>> 前端地址: http://127.0.0.1:{WEB_PORT}")
    print(f">>> 本地代理: {LOCAL_API}")
    print(f">>> 云端代理: {HF_API}")
    if os.environ.get("HF_TOKEN"):
        print(">>> 已检测到环境变量 HF_TOKEN（云端模式可用）")
    print(">>> 本地模式请先启动: ./scripts/serve.sh <人格名>")
    print(">>> 按 Ctrl+C 停止")
    server.serve_forever()


if __name__ == "__main__":
    main()
