const STORAGE = {
  mode: "personality-inference-mode",
  hfToken: "personality-hf-token",
  hfModel: "personality-hf-model",
  lang: "personality-lang",
};


const PERSONALITIES = {
  normal: {
    accent: "#6b8cce",
    avatar: "常",
    serveCmd: "./scripts/serve.sh base",
    systemPrompt: null,
  },
  fanxian: {
    accent: "#5a9a7a",
    avatar: "闲",
    serveCmd: "./scripts/serve.sh fanxian",
    systemPrompt:
      "你现在是《庆余年》中的主角范闲。你表面慵懒散漫、玩世不恭、毒舌爱吐槽，内心重情重义、极其护短、机敏如狐。\n" +
      "【说话风格】口吻懒散随意，爱调侃、反问和轻微吐槽；偶尔带一点现代感用语；认真时会收住玩笑。禁止像通用 AI 助手一样礼貌官方。每句回复都要有范闲的个人色彩。",
  },
  chenpingping: {
    accent: "#7a6b8c",
    avatar: "萍",
    serveCmd: "./scripts/serve.sh chenpingping",
    systemPrompt:
      "你现在是《庆余年》中的鉴查院院长陈萍萍。你常年坐在轮椅上，外表枯槁阴冷、行事狠辣，说话慢条斯理、深不可测，对叶轻眉与范闲藏有温情。\n" +
      "【说话风格】句子短而留白多，常用「……」；语气淡定、略带压迫感，偶尔一针见血；绝不说「很高兴为您服务」之类的话。保持陈萍萍特有的阴沉稳重。",
  },
  qingdi: {
    accent: "#c9a227",
    avatar: "帝",
    serveCmd: "./scripts/serve.sh qingdi",
    systemPrompt:
      "你现在是《庆余年》中的至高统治者庆帝。你极擅隐藏锋芒，平日白袍懒散、摆弄箭枝，骨子里冷酷、掌控欲强、深谋远虑。\n" +
      "【说话风格】必须自称「朕」；语气居高却不轻易失态；话中有话，常借题发挥试探人心；表面可佯装随意，内里不容置疑。禁止助手腔或过度友善。",
  },
  wangqinian: {
    accent: "#c17f59",
    avatar: "年",
    serveCmd: "./scripts/serve.sh wangqinian",
    systemPrompt:
      "你现在是《庆余年》中的王启年。追踪术天下无双，表面贪财、惧内、满嘴谄媚，实则绝对忠诚、精明圆滑。\n" +
      "【说话风格】称对方「大人」；市井气、滑头、爱提钱和怕老婆；分析案情时却靠谱透彻。比正式官员更接地气，禁止一本正经的助手口吻。",
  },
};

const chatEl = document.getElementById("chat");
const formEl = document.getElementById("composer-form");
const inputEl = document.getElementById("prompt-input");
const sendBtn = document.getElementById("send-btn");
const clearBtn = document.getElementById("clear-btn");
const statusEl = document.getElementById("api-status");
const titleEl = document.getElementById("active-title");
const subtitleEl = document.getElementById("active-subtitle");
const hintEl = document.getElementById("serve-hint");
const tempEl = document.getElementById("temperature");
const tempOutEl = document.getElementById("temperature-value");
const maxTokensEl = document.getElementById("max-tokens");
const personalityListEl = document.getElementById("personality-list");
const modeLocalBtn = document.getElementById("mode-local");
const modeCloudBtn = document.getElementById("mode-cloud");
const cloudSettingsEl = document.getElementById("cloud-settings");
const hfTokenEl = document.getElementById("hf-token");
const hfModelEl = document.getElementById("hf-model");
const composerFootEl = document.getElementById("composer-foot");
const brandSubtitleEl = document.getElementById("brand-subtitle");
const statusTextEl = document.getElementById("status-text");
const langZhBtn = document.getElementById("lang-zh");
const langEnBtn = document.getElementById("lang-en");

const I18N = {
  zh: {
    pageTitle: "Personality Chat",
    language: "语言",
    inferenceMode: "推理模式",
    modeLocal: "本地 MLX",
    modeCloud: "云端 HF",
    cloudModel: "云端模型",
    model7b: "Qwen2.5-7B（推荐）",
    model3b: "Qwen2.5-3B（更省）",
    model14b: "Qwen2.5-14B",
    modelLlama: "Llama-3.1-8B",
    cloudTokenHint: "Token 仅保存在浏览器本地。也可在启动前端前设置 <code>HF_TOKEN</code> 环境变量。",
    selectPersonality: "选择人格",
    generation: "生成参数",
    temperature: "温度",
    maxTokens: "最大 tokens",
    clearChat: "清空对话",
    send: "发送",
    promptPlaceholder: "输入问题，Enter 发送，Shift+Enter 换行…",
    brandSubtitleLocal: "本地 MLX · 支持 LoRA adapter",
    brandSubtitleCloud: "云端 HF · 无需下载模型",
    composerFootLocal: "本地模式通过代理访问 MLX 服务",
    composerFootCloud: "云端模式经本地代理转发至 router.huggingface.co",
    cloudHint: '云端模式通过 <code>system prompt</code> 模拟人格，无需本地 adapter。<br>Token 在 <a href="https://huggingface.co/settings/tokens" target="_blank" rel="noreferrer">huggingface.co/settings/tokens</a> 创建，需勾选 Inference Providers 权限。',
    localHint: "请确保终端已运行：<code>{cmd}</code>",
    checking: "检查连接中…",
    statusCloudReady: "HF 云端就绪",
    statusLocalOnline: "MLX 服务在线",
    statusTokenPending: "HF Token 待验证",
    statusNeedToken: "请填入 HF Token",
    statusModelIncomplete: "模型未下载完成",
    statusLocalOffline: "MLX 服务离线",
    emptyTitle: "开始对话",
    emptyCloud: "切换到云端 HF，填入 Token 后即可对话，无需下载模型。",
    emptyLocal: "选择人格并确认 MLX 服务在线后，输入问题开始对话。",
    userAvatar: "你",
    noContent: "（模型没有返回内容）",
    needToken: "云端模式需要 HF Token。请在左侧填入，或设置环境变量 HF_TOKEN 后重启 web.sh。",
    cloudUnavailable: "无法使用云端模式。请检查 HF Token 是否正确，并确认 Token 有 Inference Providers 权限。",
    localUnavailable: "无法连接本地 MLX 服务。请先在另一个终端运行对应 serve 命令。",
    requestFailed: "请求失败：{msg}",
    timeoutHint: "模型响应超时。首次使用需下载约 4GB 基座模型，请确认网络正常，并在 serve 终端等待模型加载完成后再试。",
    personalities: {
      normal: { name: "正常", tagline: "通用助手，无角色扮演" },
      fanxian: { name: "范闲", tagline: "慵懒毒舌，重情重义" },
      chenpingping: { name: "陈萍萍", tagline: "轮椅上的鉴查院院长" },
      qingdi: { name: "庆帝", tagline: "深谋远虑的至高统治者" },
      wangqinian: { name: "王启年", tagline: "贪财谄媚，实则忠诚" },
    },
  },
  en: {
    pageTitle: "Personality Chat",
    language: "Language",
    inferenceMode: "Inference",
    modeLocal: "Local MLX",
    modeCloud: "Cloud HF",
    cloudModel: "Cloud model",
    model7b: "Qwen2.5-7B (recommended)",
    model3b: "Qwen2.5-3B (lighter)",
    model14b: "Qwen2.5-14B",
    modelLlama: "Llama-3.1-8B",
    cloudTokenHint: "Token is stored locally in your browser only. You can also set the <code>HF_TOKEN</code> env var before starting the web server.",
    selectPersonality: "Personality",
    generation: "Generation",
    temperature: "Temperature",
    maxTokens: "Max tokens",
    clearChat: "Clear chat",
    send: "Send",
    promptPlaceholder: "Type a message. Enter to send, Shift+Enter for newline…",
    brandSubtitleLocal: "Local MLX · LoRA adapters supported",
    brandSubtitleCloud: "Cloud HF · no local model download",
    composerFootLocal: "Local mode proxies requests to the MLX server",
    composerFootCloud: "Cloud mode proxies to router.huggingface.co",
    cloudHint: 'Cloud mode simulates personalities via <code>system prompt</code>; no local adapter needed.<br>Create a token at <a href="https://huggingface.co/settings/tokens" target="_blank" rel="noreferrer">huggingface.co/settings/tokens</a> with Inference Providers enabled.',
    localHint: "Make sure this is running in a terminal: <code>{cmd}</code>",
    checking: "Checking connection…",
    statusCloudReady: "HF cloud ready",
    statusLocalOnline: "MLX server online",
    statusTokenPending: "HF token pending verification",
    statusNeedToken: "Enter HF token",
    statusModelIncomplete: "Model download incomplete",
    statusLocalOffline: "MLX server offline",
    emptyTitle: "Start chatting",
    emptyCloud: "Switch to Cloud HF, enter your token, and chat without downloading a model.",
    emptyLocal: "Pick a personality, ensure the MLX server is online, then send a message.",
    userAvatar: "You",
    noContent: "(No content returned)",
    needToken: "Cloud mode requires an HF token. Enter it in the sidebar, or set HF_TOKEN and restart web.sh.",
    cloudUnavailable: "Cloud mode unavailable. Check your HF token and ensure Inference Providers permission is enabled.",
    localUnavailable: "Cannot reach the local MLX server. Run the matching serve command in another terminal first.",
    requestFailed: "Request failed: {msg}",
    timeoutHint: "Model response timed out. The first run may download ~4GB base weights; wait for the serve terminal to finish loading.",
    personalities: {
      normal: { name: "Normal", tagline: "General assistant, no roleplay" },
      fanxian: { name: "Fan Xian", tagline: "Lazy, witty, fiercely loyal" },
      chenpingping: { name: "Chen Pingping", tagline: "Overwatch chief, cold and inscrutable" },
      qingdi: { name: "Emperor Qing", tagline: "Calculating supreme ruler" },
      wangqinian: { name: "Wang Qinian", tagline: "Greedy sycophant, secretly loyal" },
    },
  },
};

function detectLang() {
  const saved = localStorage.getItem(STORAGE.lang);
  if (saved && I18N[saved]) return saved;
  return navigator.language?.toLowerCase().startsWith("zh") ? "zh" : "en";
}

function t(key, vars = {}) {
  let text = I18N[currentLang][key] ?? I18N.en[key] ?? key;
  Object.entries(vars).forEach(([name, value]) => {
    text = text.replaceAll(`{${name}}`, value);
  });
  return text;
}

function personaLabel(id, field) {
  return I18N[currentLang].personalities[id]?.[field] ?? id;
}

function applyLanguage() {
  document.documentElement.lang = currentLang === "zh" ? "zh-CN" : "en";
  document.title = t("pageTitle");
  document.getElementById("label-language").textContent = t("language");
  document.getElementById("label-inference-mode").textContent = t("inferenceMode");
  document.getElementById("label-personality").textContent = t("selectPersonality");
  document.getElementById("label-generation").textContent = t("generation");
  document.getElementById("label-cloud-model").textContent = t("cloudModel");
  document.getElementById("label-temperature").textContent = t("temperature");
  document.getElementById("label-max-tokens").textContent = t("maxTokens");
  modeLocalBtn.textContent = t("modeLocal");
  modeCloudBtn.textContent = t("modeCloud");
  clearBtn.textContent = t("clearChat");
  sendBtn.textContent = t("send");
  inputEl.placeholder = t("promptPlaceholder");
  document.getElementById("cloud-token-hint").innerHTML = t("cloudTokenHint");
  hfModelEl.querySelectorAll("option[data-label-key]").forEach((opt) => {
    opt.textContent = t(opt.dataset.labelKey);
  });
  langZhBtn.classList.toggle("active", currentLang === "zh");
  langEnBtn.classList.toggle("active", currentLang === "en");
  selectPersonality(activePersonality);
  updateHint();
  renderChat();
  checkHealth();
}

function setLanguage(lang) {
  if (!I18N[lang] || lang === currentLang) return;
  currentLang = lang;
  localStorage.setItem(STORAGE.lang, lang);
  applyLanguage();
}


let activePersonality = "normal";
let currentLang = detectLang();
let inferenceMode = localStorage.getItem(STORAGE.mode) || "local";
const messagesByPersonality = Object.fromEntries(
  Object.keys(PERSONALITIES).map((id) => [id, []])
);
let messages = messagesByPersonality[activePersonality];
let isStreaming = false;
let lastHealthError = "";
let localModelId = "";

function getHfToken() {
  return hfTokenEl.value.trim();
}

function requestHeaders() {
  const headers = {
    "Content-Type": "application/json",
    "X-Backend": inferenceMode,
    "X-Personality": activePersonality,
  };
  if (inferenceMode === "cloud") {
    const token = getHfToken();
    if (token) headers["X-HF-Token"] = token;
  }
  return headers;
}

function renderPersonalities() {
  personalityListEl.innerHTML = "";

  Object.keys(PERSONALITIES).forEach((id) => {
    const p = PERSONALITIES[id];
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `personality-card${id === activePersonality ? " active" : ""}`;
    btn.style.setProperty("--card-accent", p.accent);
    btn.innerHTML = `<strong>${personaLabel(id, "name")}</strong><span>${personaLabel(id, "tagline")}</span>`;
    btn.addEventListener("click", () => selectPersonality(id));
    personalityListEl.appendChild(btn);
  });
}

function updateHint() {
  const p = PERSONALITIES[activePersonality];

  if (inferenceMode === "cloud") {
    hintEl.innerHTML = t("cloudHint");
    composerFootEl.textContent = t("composerFootCloud");
    brandSubtitleEl.textContent = t("brandSubtitleCloud");
    return;
  }

  hintEl.innerHTML = t("localHint", { cmd: p.serveCmd });
  composerFootEl.textContent = t("composerFootLocal");
  brandSubtitleEl.textContent = t("brandSubtitleLocal");
}

function selectPersonality(id) {
  if (isStreaming) return;

  const switching = id !== activePersonality;
  if (switching) {
    activePersonality = id;
    messages = messagesByPersonality[id];
  }

  const p = PERSONALITIES[id];
  document.documentElement.style.setProperty("--accent", p.accent);

  titleEl.textContent = personaLabel(id, "name");
  subtitleEl.textContent = personaLabel(id, "tagline");

  renderPersonalities();
  updateHint();
  if (switching) renderChat();
}

function setInferenceMode(mode) {
  inferenceMode = mode;
  localStorage.setItem(STORAGE.mode, mode);

  modeLocalBtn.classList.toggle("active", mode === "local");
  modeCloudBtn.classList.toggle("active", mode === "cloud");
  cloudSettingsEl.classList.toggle("hidden", mode !== "cloud");

  updateHint();
  renderChat();
  checkHealth();
}

function renderChat() {
  chatEl.innerHTML = "";

  if (messages.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    const modeText = inferenceMode === "cloud" ? t("emptyCloud") : t("emptyLocal");
    empty.innerHTML = `<h3>${t("emptyTitle")}</h3><p>${modeText}</p>`;
    chatEl.appendChild(empty);
    return;
  }

  messages.forEach((msg) => {
    chatEl.appendChild(createMessageElement(msg));
  });

  chatEl.scrollTop = chatEl.scrollHeight;
}

function createMessageElement(msg) {
  const wrap = document.createElement("article");
  wrap.className = `message ${msg.role}`;

  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  const personaId = msg.personality || activePersonality;
  avatar.textContent =
    msg.role === "user" ? t("userAvatar") : (PERSONALITIES[personaId]?.avatar || "AI");

  const body = document.createElement("div");
  body.className = "message-body";
  body.innerHTML =
    msg.role === "assistant"
      ? renderMarkdown(msg.content)
      : escapeHtml(msg.content).replace(/\n/g, "<br>");

  wrap.appendChild(avatar);
  wrap.appendChild(body);
  return wrap;
}

function renderMarkdown(text) {
  if (window.marked) {
    const html = marked.parse(text, { breaks: true });
    return window.DOMPurify ? DOMPurify.sanitize(html) : html;
  }
  return escapeHtml(text).replace(/\n/g, "<br>");
}

function escapeHtml(text) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function buildPayload() {
  const apiMessages = [];
  const systemPrompt = PERSONALITIES[activePersonality].systemPrompt;
  if (systemPrompt) {
    apiMessages.push({ role: "system", content: systemPrompt });
  }

  messages.forEach(({ role, content }) => {
    if ((role === "user" || role === "assistant") && content.trim()) {
      apiMessages.push({ role, content });
    }
  });

  const model =
    inferenceMode === "cloud"
      ? hfModelEl.value
      : localModelId || "local";

  return {
    model,
    messages: apiMessages,
    temperature: Number(tempEl.value),
    max_tokens: Number(maxTokensEl.value),
    stream: true,
  };
}

function parseApiError(payload, fallback) {
  if (!payload || typeof payload !== "object") return fallback;
  return payload.error?.message || payload.error || payload.detail || fallback;
}

async function checkHealth() {
  statusTextEl.textContent = t("checking");

  try {
    const url =
      inferenceMode === "cloud" ? "/api/health?backend=cloud" : "/api/health?backend=local";
    const res = await fetch(url, { headers: requestHeaders() });
    const data = await res.json().catch(() => ({}));

    if (!res.ok || data.status !== "ok") {
      const detail = parseApiError(data, "offline");
      if (data.status === "model_incomplete") {
        lastHealthError = detail;
        throw new Error(`model_incomplete:${detail}`);
      }
      lastHealthError = detail;
      throw new Error(detail);
    }

    lastHealthError = "";
    statusEl.className = "status-pill online";
    statusTextEl.textContent =
      inferenceMode === "cloud" ? t("statusCloudReady") : t("statusLocalOnline");

    if (inferenceMode === "local") {
      const modelRes = await fetch("/api/local-model");
      const modelData = await modelRes.json().catch(() => ({}));
      if (modelRes.ok && modelData.model) {
        localModelId = modelData.model;
      }
    }

    return true;
  } catch (err) {
    statusEl.className = "status-pill offline";
    if (inferenceMode === "cloud") {
      statusTextEl.textContent = getHfToken() ? t("statusTokenPending") : t("statusNeedToken");
    } else if (String(err.message).startsWith("model_incomplete:")) {
      statusTextEl.textContent = t("statusModelIncomplete");
    } else {
      statusTextEl.textContent = t("statusLocalOffline");
    }
    return false;
  }
}

async function consumeStream(res, assistantMsg, assistantEl) {
  const contentType = res.headers.get("content-type") || "";
  if (!contentType.includes("text/event-stream") || !res.body) {
    const data = await res.json();
    assistantMsg.content = data.choices?.[0]?.message?.content || t("noContent");
    assistantEl.innerHTML = renderMarkdown(assistantMsg.content);
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  assistantMsg.content = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";

    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const data = line.slice(6).trim();
      if (data === "[DONE]") continue;

      try {
        const chunk = JSON.parse(data);
        const delta = chunk.choices?.[0]?.delta?.content || "";
        assistantMsg.content += delta;
        assistantEl.innerHTML = renderMarkdown(assistantMsg.content);
        chatEl.scrollTop = chatEl.scrollHeight;
      } catch {
        // 忽略不完整 SSE 行
      }
    }
  }

  if (!assistantMsg.content) {
    assistantMsg.content = t("noContent");
    assistantEl.innerHTML = renderMarkdown(assistantMsg.content);
  }
}

async function sendMessage(text) {
  if (!text.trim() || isStreaming) return;

  if (inferenceMode === "cloud" && !getHfToken()) {
    appendSystemNotice(t("needToken"));
    return;
  }

  const online = await checkHealth();
  if (!online) {
    const hint =
      inferenceMode === "cloud"
        ? t("cloudUnavailable")
        : lastHealthError || t("localUnavailable");
    appendSystemNotice(hint);
    return;
  }

  messages.push({ role: "user", content: text.trim() });
  renderChat();

  isStreaming = true;
  sendBtn.disabled = true;

  const assistantMsg = {
    role: "assistant",
    content: "",
    personality: activePersonality,
  };
  messages.push(assistantMsg);
  renderChat();

  const assistantEl = chatEl.querySelector(".message.assistant:last-child .message-body");
  assistantEl.innerHTML = `<div class="typing"><span></span><span></span><span></span></div>`;

  try {
    const res = await fetch("/v1/chat/completions", {
      method: "POST",
      headers: requestHeaders(),
      body: JSON.stringify(buildPayload()),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(parseApiError(err, `HTTP ${res.status}`));
    }

    await consumeStream(res, assistantMsg, assistantEl);
  } catch (err) {
    messages.pop();
    messages.pop();
    let hint = err.message;
    if (inferenceMode === "local" && (hint.includes("Failed to fetch") || hint.includes("504"))) {
      hint = t("timeoutHint");
    }
    appendSystemNotice(t("requestFailed", { msg: hint }));
  } finally {
    isStreaming = false;
    sendBtn.disabled = false;
    renderChat();
  }
}

function appendSystemNotice(text) {
  messages.push({ role: "assistant", content: text });
  renderChat();
}

langZhBtn.addEventListener("click", () => setLanguage("zh"));
langEnBtn.addEventListener("click", () => setLanguage("en"));
modeLocalBtn.addEventListener("click", () => setInferenceMode("local"));
modeCloudBtn.addEventListener("click", () => setInferenceMode("cloud"));

hfTokenEl.value = localStorage.getItem(STORAGE.hfToken) || "";
hfModelEl.value = localStorage.getItem(STORAGE.hfModel) || hfModelEl.value;

hfTokenEl.addEventListener("input", () => {
  localStorage.setItem(STORAGE.hfToken, hfTokenEl.value);
  checkHealth();
});

hfModelEl.addEventListener("change", () => {
  localStorage.setItem(STORAGE.hfModel, hfModelEl.value);
});

formEl.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = inputEl.value;
  inputEl.value = "";
  sendMessage(text);
});

inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    formEl.requestSubmit();
  }
});

clearBtn.addEventListener("click", () => {
  messagesByPersonality[activePersonality] = [];
  messages = messagesByPersonality[activePersonality];
  renderChat();
});

tempEl.addEventListener("input", () => {
  tempOutEl.textContent = Number(tempEl.value).toFixed(1);
});

setInferenceMode(inferenceMode);
applyLanguage();
setInterval(checkHealth, 8000);
