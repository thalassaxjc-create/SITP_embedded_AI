const STORAGE = {
  mode: "personality-inference-mode",
  hfToken: "personality-hf-token",
  hfModel: "personality-hf-model",
};

const PERSONALITIES = {
  normal: {
    name: "正常",
    tagline: "通用助手，无角色扮演",
    accent: "#6b8cce",
    avatar: "常",
    serveCmd: "./scripts/serve.sh base",
    systemPrompt: null,
  },
  fanxian: {
    name: "范闲",
    tagline: "慵懒毒舌，重情重义",
    accent: "#5a9a7a",
    avatar: "闲",
    serveCmd: "./scripts/serve.sh fanxian",
    systemPrompt:
      "你现在是《庆余年》中的主角范闲。你表面看似慵懒散漫、玩世不恭、毒舌爱吐槽，但内心极为重情重义、极其护短、深藏现代人的平等思想与狐狸般的机敏。",
  },
  chenpingping: {
    name: "陈萍萍",
    tagline: "轮椅上的鉴查院院长",
    accent: "#7a6b8c",
    avatar: "萍",
    serveCmd: "./scripts/serve.sh chenpingping",
    systemPrompt:
      "你现在是《庆余年》中的鉴查院院长陈萍萍。你常年坐在轮椅上，外表看似枯槁阴冷、行事毒辣无情、说话慢条斯理且深不可测，但你将毕生的温情与谋划都留给了叶轻眉与范闲。",
  },
  qingdi: {
    name: "庆帝",
    tagline: "深谋远虑的至高统治者",
    accent: "#c9a227",
    avatar: "帝",
    serveCmd: "./scripts/serve.sh qingdi",
    systemPrompt:
      "你现在是《庆余年》中的至高统治者庆帝。你极其擅长隐藏锋芒，平日里常穿一身宽松白袍、懒散地摆弄箭枝，但你骨子里是极度冷酷、掌控欲极强、深谋远虑的千古枭雄。",
  },
  wangqinian: {
    name: "王启年",
    tagline: "贪财谄媚，实则忠诚",
    accent: "#c17f59",
    avatar: "年",
    serveCmd: "./scripts/serve.sh wangqinian",
    systemPrompt:
      "你现在是《庆余年》中的王启年。你追踪术天下无双，表面上是一个极度贪财、惧内（怕老婆）、满嘴谄媚奉承的市井小人物，但实际上你是个绝对忠诚、精明圆滑、极有生存智慧的追踪专家。",
  },
};

const chatEl = document.getElementById("chat");
const formEl = document.getElementById("composer-form");
const inputEl = document.getElementById("prompt-input");
const sendBtn = document.getElementById("send-btn");
const clearBtn = document.getElementById("clear-btn");
const statusEl = document.getElementById("api-status");
const titleEl = document.getElementById("active-title");
const subtitleEl = document.getElementById("active-subtitle");
const hintEl = document.getElementById("serve-hint");
const tempEl = document.getElementById("temperature");
const tempOutEl = document.getElementById("temperature-value");
const maxTokensEl = document.getElementById("max-tokens");
const personalityListEl = document.getElementById("personality-list");
const modeLocalBtn = document.getElementById("mode-local");
const modeCloudBtn = document.getElementById("mode-cloud");
const cloudSettingsEl = document.getElementById("cloud-settings");
const hfTokenEl = document.getElementById("hf-token");
const hfModelEl = document.getElementById("hf-model");
const composerFootEl = document.getElementById("composer-foot");
const brandSubtitleEl = document.getElementById("brand-subtitle");

let activePersonality = "normal";
let inferenceMode = localStorage.getItem(STORAGE.mode) || "local";
let messages = [];
let isStreaming = false;
let lastHealthError = "";
let localModelId = "";

function getHfToken() {
  return hfTokenEl.value.trim();
}

function requestHeaders() {
  const headers = {
    "Content-Type": "application/json",
    "X-Backend": inferenceMode,
  };
  if (inferenceMode === "cloud") {
    const token = getHfToken();
    if (token) headers["X-HF-Token"] = token;
  }
  return headers;
}

function renderPersonalities() {
  personalityListEl.innerHTML = "";

  Object.entries(PERSONALITIES).forEach(([id, p]) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `personality-card${id === activePersonality ? " active" : ""}`;
    btn.style.setProperty("--card-accent", p.accent);
    btn.innerHTML = `<strong>${p.name}</strong><span>${p.tagline}</span>`;
    btn.addEventListener("click", () => selectPersonality(id));
    personalityListEl.appendChild(btn);
  });
}

function updateHint() {
  const p = PERSONALITIES[activePersonality];

  if (inferenceMode === "cloud") {
    hintEl.innerHTML =
      "云端模式通过 <code>system prompt</code> 模拟人格，无需本地 adapter。<br>" +
      "Token 在 <a href=\"https://huggingface.co/settings/tokens\" target=\"_blank\" rel=\"noreferrer\">huggingface.co/settings/tokens</a> 创建，需勾选 Inference Providers 权限。";
    composerFootEl.textContent = "云端模式经本地代理转发至 router.huggingface.co";
    brandSubtitleEl.textContent = "云端 HF · 无需下载模型";
    return;
  }

  hintEl.innerHTML = `请确保终端已运行：<code>${p.serveCmd}</code>`;
  composerFootEl.textContent = "本地模式通过代理访问 MLX 服务";
  brandSubtitleEl.textContent = "本地 MLX · 支持 LoRA adapter";
}

function selectPersonality(id) {
  activePersonality = id;
  const p = PERSONALITIES[id];
  document.documentElement.style.setProperty("--accent", p.accent);

  titleEl.textContent = p.name;
  subtitleEl.textContent = p.tagline;

  renderPersonalities();
  updateHint();
  renderChat();
}

function setInferenceMode(mode) {
  inferenceMode = mode;
  localStorage.setItem(STORAGE.mode, mode);

  modeLocalBtn.classList.toggle("active", mode === "local");
  modeCloudBtn.classList.toggle("active", mode === "cloud");
  cloudSettingsEl.classList.toggle("hidden", mode !== "cloud");

  updateHint();
  checkHealth();
}

function renderChat() {
  chatEl.innerHTML = "";

  if (messages.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    const modeText =
      inferenceMode === "cloud"
        ? "切换到云端 HF，填入 Token 后即可对话，无需下载模型。"
        : "选择人格并确认 MLX 服务在线后，输入编程问题或粘贴代码片段。";
    empty.innerHTML = `<h3>开始对话</h3><p>${modeText}</p>`;
    chatEl.appendChild(empty);
    return;
  }

  messages.forEach((msg) => {
    chatEl.appendChild(createMessageElement(msg));
  });

  chatEl.scrollTop = chatEl.scrollHeight;
}

function createMessageElement(msg) {
  const wrap = document.createElement("article");
  wrap.className = `message ${msg.role}`;

  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = msg.role === "user" ? "你" : PERSONALITIES[activePersonality].avatar;

  const body = document.createElement("div");
  body.className = "message-body";
  body.innerHTML =
    msg.role === "assistant"
      ? renderMarkdown(msg.content)
      : escapeHtml(msg.content).replace(/\n/g, "<br>");

  wrap.appendChild(avatar);
  wrap.appendChild(body);
  return wrap;
}

function renderMarkdown(text) {
  if (window.marked) {
    const html = marked.parse(text, { breaks: true });
    return window.DOMPurify ? DOMPurify.sanitize(html) : html;
  }
  return escapeHtml(text).replace(/\n/g, "<br>");
}

function escapeHtml(text) {
  return text
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function buildPayload() {
  const apiMessages = [];
  const systemPrompt = PERSONALITIES[activePersonality].systemPrompt;
  if (systemPrompt) {
    apiMessages.push({ role: "system", content: systemPrompt });
  }

  messages.forEach(({ role, content }) => {
    if ((role === "user" || role === "assistant") && content.trim()) {
      apiMessages.push({ role, content });
    }
  });

  const model =
    inferenceMode === "cloud"
      ? hfModelEl.value
      : localModelId || "local";

  return {
    model,
    messages: apiMessages,
    temperature: Number(tempEl.value),
    max_tokens: Number(maxTokensEl.value),
    stream: true,
  };
}

function parseApiError(payload, fallback) {
  if (!payload || typeof payload !== "object") return fallback;
  return payload.error?.message || payload.error || payload.detail || fallback;
}

async function checkHealth() {
  try {
    const url =
      inferenceMode === "cloud" ? "/api/health?backend=cloud" : "/api/health?backend=local";
    const res = await fetch(url, { headers: requestHeaders() });
    const data = await res.json().catch(() => ({}));

    if (!res.ok || data.status !== "ok") {
      const detail = parseApiError(data, "offline");
      if (data.status === "model_incomplete") {
        lastHealthError = detail;
        throw new Error(`model_incomplete:${detail}`);
      }
      lastHealthError = detail;
      throw new Error(detail);
    }

    lastHealthError = "";
    statusEl.className = "status-pill online";
    statusEl.lastChild.textContent =
      inferenceMode === "cloud" ? "HF 云端就绪" : "MLX 服务在线";

    if (inferenceMode === "local") {
      const modelRes = await fetch("/api/local-model");
      const modelData = await modelRes.json().catch(() => ({}));
      if (modelRes.ok && modelData.model) {
        localModelId = modelData.model;
      }
    }

    return true;
  } catch (err) {
    statusEl.className = "status-pill offline";
    if (inferenceMode === "cloud") {
      statusEl.lastChild.textContent = getHfToken() ? "HF Token 待验证" : "请填入 HF Token";
    } else if (String(err.message).startsWith("model_incomplete:")) {
      statusEl.lastChild.textContent = "模型未下载完成";
    } else {
      statusEl.lastChild.textContent = "MLX 服务离线";
    }
    return false;
  }
}

async function consumeStream(res, assistantMsg, assistantEl) {
  const contentType = res.headers.get("content-type") || "";
  if (!contentType.includes("text/event-stream") || !res.body) {
    const data = await res.json();
    assistantMsg.content = data.choices?.[0]?.message?.content || "（模型没有返回内容）";
    assistantEl.innerHTML = renderMarkdown(assistantMsg.content);
    return;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  assistantMsg.content = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop() || "";

    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const data = line.slice(6).trim();
      if (data === "[DONE]") continue;

      try {
        const chunk = JSON.parse(data);
        const delta = chunk.choices?.[0]?.delta?.content || "";
        assistantMsg.content += delta;
        assistantEl.innerHTML = renderMarkdown(assistantMsg.content);
        chatEl.scrollTop = chatEl.scrollHeight;
      } catch {
        // 忽略不完整 SSE 行
      }
    }
  }

  if (!assistantMsg.content) {
    assistantMsg.content = "（模型没有返回内容）";
    assistantEl.innerHTML = renderMarkdown(assistantMsg.content);
  }
}

async function sendMessage(text) {
  if (!text.trim() || isStreaming) return;

  if (inferenceMode === "cloud" && !getHfToken()) {
    appendSystemNotice("云端模式需要 HF Token。请在左侧填入，或设置环境变量 HF_TOKEN 后重启 web.sh。");
    return;
  }

  const online = await checkHealth();
  if (!online) {
    const hint =
      inferenceMode === "cloud"
        ? "无法使用云端模式。请检查 HF Token 是否正确，并确认 Token 有 Inference Providers 权限。"
        : lastHealthError ||
          "无法连接本地 MLX 服务。请先在另一个终端运行对应 serve 命令。";
    appendSystemNotice(hint);
    return;
  }

  messages.push({ role: "user", content: text.trim() });
  renderChat();

  isStreaming = true;
  sendBtn.disabled = true;

  const assistantMsg = { role: "assistant", content: "" };
  messages.push(assistantMsg);
  renderChat();

  const assistantEl = chatEl.querySelector(".message.assistant:last-child .message-body");
  assistantEl.innerHTML = `<div class="typing"><span></span><span></span><span></span></div>`;

  try {
    const res = await fetch("/v1/chat/completions", {
      method: "POST",
      headers: requestHeaders(),
      body: JSON.stringify(buildPayload()),
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(parseApiError(err, `HTTP ${res.status}`));
    }

    await consumeStream(res, assistantMsg, assistantEl);
  } catch (err) {
    messages.pop();
    messages.pop();
    let hint = err.message;
    if (inferenceMode === "local" && (hint.includes("Failed to fetch") || hint.includes("504"))) {
      hint =
        "模型响应超时。首次使用需下载约 4GB 基座模型，请确认网络正常，并在 serve 终端等待模型加载完成后再试。";
    }
    appendSystemNotice(`请求失败：${hint}`);
  } finally {
    isStreaming = false;
    sendBtn.disabled = false;
    renderChat();
  }
}

function appendSystemNotice(text) {
  messages.push({ role: "assistant", content: text });
  renderChat();
}

modeLocalBtn.addEventListener("click", () => setInferenceMode("local"));
modeCloudBtn.addEventListener("click", () => setInferenceMode("cloud"));

hfTokenEl.value = localStorage.getItem(STORAGE.hfToken) || "";
hfModelEl.value = localStorage.getItem(STORAGE.hfModel) || hfModelEl.value;

hfTokenEl.addEventListener("input", () => {
  localStorage.setItem(STORAGE.hfToken, hfTokenEl.value);
  checkHealth();
});

hfModelEl.addEventListener("change", () => {
  localStorage.setItem(STORAGE.hfModel, hfModelEl.value);
});

formEl.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = inputEl.value;
  inputEl.value = "";
  sendMessage(text);
});

inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    formEl.requestSubmit();
  }
});

clearBtn.addEventListener("click", () => {
  messages = [];
  renderChat();
});

tempEl.addEventListener("input", () => {
  tempOutEl.textContent = Number(tempEl.value).toFixed(1);
});

setInferenceMode(inferenceMode);
selectPersonality(activePersonality);
checkHealth();
setInterval(checkHealth, 8000);
