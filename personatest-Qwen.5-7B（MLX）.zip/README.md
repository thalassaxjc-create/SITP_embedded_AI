# **Personality 大语言模型人格微调**

在 Apple Silicon（MLX）上，基于 **Qwen2.5-7B-Instruct-4bit**

**测试**从小说《庆余年》自动提取对话数据，经 **LoRA** 微调

构建四个角色人格

通过 Web 界面与基座正常模式对照对话

---

## 一、项目内容

### 1.1 做什么


| 能力          | 说明                                            |
| ----------- | --------------------------------------------- |
| **数据提取**    | 从 `庆余年.txt` 自动识别说话人，生成四人设微调数据集                |
| **LoRA 训练** | 在共享基座上分别训练范闲、陈萍萍、庆帝、王启年                       |
| **本地对话**    | MLX 服务 + LoRA adapter，浏览器流式聊天                 |
| **云端对话**    | HuggingFace Router + system prompt，无需本地模型（可选） |
| **对照模式**    | 「正常」= 仅基座，无角色 adapter                         |


### 1.2 五个人格


| 前端 ID          | 显示名 | 数据目录                 | Adapter                  | 本地启动                              |
| -------------- | --- | -------------------- | ------------------------ | --------------------------------- |
| `normal`       | 正常  | —                    | —                        | `./scripts/serve.sh base`         |
| `fanxian`      | 范闲  | `data/fanxian/`      | `adapters/fanxian/`      | `./scripts/serve.sh fanxian`      |
| `chenpingping` | 陈萍萍 | `data/chenpingping/` | `adapters/chenpingping/` | `./scripts/serve.sh chenpingping` |
| `qingdi`       | 庆帝  | `data/qingdi/`       | `adapters/qingdi/`       | `./scripts/serve.sh qingdi`       |
| `wangqinian`   | 王启年 | `data/wangqinian/`   | `adapters/wangqinian/`   | `./scripts/serve.sh wangqinian`   |


### 1.3 完整实现路径

```
阶段 0  环境与基座
        pip install -r requirements.txt
        ./scripts/download_model.sh  →  models/Qwen2.5-7B-Instruct-4bit/

阶段 1  数据提取
        庆余年.txt (GBK)  →  extract_multi_personas.py
        →  data/{persona}/train.jsonl + valid.jsonl

阶段 2  LoRA 微调
        ./scripts/train.sh <persona>  →  adapters/<persona>/

阶段 3  推理 API
        ./scripts/serve.sh <persona|base>  →  :8080 OpenAI 兼容接口

阶段 4  Web 对话
        ./scripts/web.sh  →  http://127.0.0.1:3000
```

简图：

```
庆余年.txt → extract_multi_personas.py → data/
              → train.sh + mlx_lm.lora → adapters/
              → serve.sh + mlx_lm.server (:8080)
              → web/server.py + app.js (:3000)
```

---

## 二、基座模型


| 项               | 值                                               |
| --------------- | ----------------------------------------------- |
| **名称**          | Qwen2.5-7B-Instruct（4bit MLX 量化）                |
| **HuggingFace** | `mlx-community/Qwen2.5-7B-Instruct-4bit`        |
| **本地路径**        | `models/Qwen2.5-7B-Instruct-4bit/`              |
| **体积**          | 约 **4 GB**（`model.safetensors`）                 |
| **下载**          | `./scripts/download_model.sh`（默认 hf-mirror.com） |
| **校验**          | `./scripts/verify_model.sh`                     |
| **训练配置**        | `config/base.yaml` 中 `model:` 字段                |


**加载逻辑**（`train.sh` / `serve.sh`）：

1. 若存在 `models/Qwen2.5-7B-Instruct-4bit/config.json` → 使用本地路径
2. 否则 → 在线拉取同一 HF 仓库


| 模式                   | 加载内容                          |
| -------------------- | ----------------------------- |
| `serve.sh base`      | 仅基座，无 LoRA（正常模式）              |
| `serve.sh fanxian` 等 | 基座 + 对应 `adapters/<persona>/` |


---

## 三、目录结构

```
personality/
├── README.md                   # 本文档
├── extract_multi_personas.py   # 多角色对话提取
├── requirements.txt            # mlx-lm[train]>=0.21.0
├── config/base.yaml            # LoRA 超参
├── data/{persona}/             # train.jsonl + valid.jsonl
├── adapters/{persona}/         # LoRA 权重（训练产出）
├── models/Qwen2.5-7B-Instruct-4bit/  # 基座（约 4GB，可单独分包）
├── scripts/                    # download / train / serve / web 等
└── web/                        # 前端 + API 反向代理
    ├── index.html
    ├── app.js
    ├── server.py
    └── styles.css
```

---

## 四、技术说明

### 4.1 数据提取 `extract_multi_personas.py`

**输入**：默认 `/Users/cassini/Downloads/庆余年.txt`，编码自动识别 GBK / GB18030 / UTF-8。

**说话人识别**（发言归因引擎）：

- 按 `。！？` 及书中 `.` 分句  
- 匹配 `范闲应道："……"`、`陈萍萍微笑道："……"` 等句式  
- 别名：庆帝←皇帝/陛下；陈萍萍←老跛子/院长  
- 支持弯引号 `"` `"`、直角引号 `「」`  
- 过滤「范闲知道」「向范闲道谢」等误匹配

**样本结构**：

- `user`：上一句有效上下文  
- `assistant`：该角色发言句（含神态与引语）  
- `system`：角色设定（见脚本内 `PERSONA_CONFIG`）

**JSONL 格式**（每行一条）：

```json
{
  "messages": [
    {"role": "system", "content": "你现在是《庆余年》中的主角范闲。……"},
    {"role": "user", "content": "上一段上下文……"},
    {"role": "assistant", "content": "范闲应道：\"……\""}
  ]
}
```

**导出**：每角色独立 shuffle，8:2 划分 train / valid。

```bash
python extract_multi_personas.py \
  --source /path/to/庆余年.txt \
  --output ./data \
  --train-ratio 0.8 \
  --seed 42
```

### 4.2 训练 `config/base.yaml`


| 参数             | 值    | 说明                 |
| -------------- | ---- | ------------------ |
| batch_size     | 1    | M2 16GB 友好         |
| num_layers     | 8    | LoRA 层数            |
| iters          | 600  | 训练步数               |
| learning_rate  | 1e-5 |                    |
| max_seq_length | 2048 |                    |
| mask_prompt    | true | 仅 assistant 计 loss |


```bash
./scripts/train.sh fanxian
# → mlx_lm.lora --data data/fanxian --adapter-path adapters/fanxian
```

### 4.3 推理与 Web

**MLX Server**（`:8080`）：OpenAI 兼容 `/v1/chat/completions`，支持 SSE 流式。

**Web 代理**（`:3000`）：


| 模式     | 后端                      | 人格来源                         |
| ------ | ----------------------- | ---------------------------- |
| 本地 MLX | `mlx_lm.server`         | LoRA adapter + system prompt |
| 云端 HF  | `router.huggingface.co` | 仅 system prompt（需 HF Token）  |


环境变量：`WEB_PORT`、`API_URL`、`HF_TOKEN`、`CHAT_TIMEOUT`。

**推理数据流**：

```
浏览器 → POST /v1/chat/completions
      → web/server.py 转发
      → mlx_lm.server（基座 ± adapter）
      → SSE 流式返回 → Markdown 渲染
```

### 4.4 依赖与环境

- **系统**：macOS，Apple Silicon，建议内存 ≥ 16GB  
- **Python**：3.10+  
- **依赖**：`pip install -r requirements.txt`  
- **端口**：8080（API）、3000（Web）

### 4.5 txt识别限制条件

1. 说话人识别基于规则，无法处理纯代词归因（「他冷笑道」且无姓名）
2. 云端模式无 LoRA，风格弱于本地微调
3. 本地 `serve.sh` 一次只能挂载一个人格，切换需重启
4. 提取质量依赖 `庆余年.txt` 版本与编码

### 4.6 扩展新角色

1. 在 `extract_multi_personas.py` 的 `PERSONA_CONFIG` 添加角色
2. 运行提取 → `./scripts/train.sh <id>`
3. 在 `web/app.js` 的 `PERSONALITIES` 注册 UI

---

## 五、操作指南

### 5.1 首次完整流程

```bash
cd personality
pip install -r requirements.txt
./scripts/download_model.sh
python extract_multi_personas.py
./scripts/train.sh fanxian          # 及其他角色
./scripts/start.sh fanxian          # 或分终端 serve + web
# 浏览器 http://127.0.0.1:3000 ，选择「范闲」
```

### 5.2 日常启动（已训练）

```bash
# 终端 1
./scripts/serve.sh fanxian

# 终端 2
./scripts/web.sh
```

一键：`./scripts/start.sh fanxian`

**注意**：前端所选人格须与 `serve.sh` 参数一致；切换角色时 Ctrl+C 重启 serve。

### 5.3 云端 HF 模式

1. 创建 [HF Token](https://huggingface.co/settings/tokens)（Inference Providers 权限）
2. 前端切「云端 HF」，填入 Token
3. 无需本地模型与 adapter（人格靠 prompt 模拟）

```bash
export HF_TOKEN=hf_xxxxxxxx
./scripts/web.sh
```

### 5.4 常用命令

```bash
python extract_multi_personas.py      # 提取数据
./scripts/train.sh <persona>          # 训练
./scripts/serve.sh <persona|base>     # API 服务
./scripts/web.sh                      # Web 前端
./scripts/start.sh <persona|base>     # 一键启动
./scripts/generate.sh fanxian "你好"  # 命令行测试
./scripts/free_port.sh 8080           # 释放端口
./scripts/test_api.sh                 # API 冒烟测试
```

### 5.5 典型场景

**切换为庆帝**：停止当前 serve → `./scripts/serve.sh qingdi` → 前端选「庆帝」  

**对照实验**：`serve.sh base` + 前端「正常」 vs `serve.sh fanxian` + 前端「范闲」，同一问题对比风格  

### 5.6 故障排查


| 现象          | 处理                                                |
| ----------- | ------------------------------------------------- |
| MLX 服务离线    | 确认 `serve.sh` 在跑；`free_port.sh 8080` 后重启          |
| 模型未下载完成     | `./scripts/download_model.sh` + `verify_model.sh` |
| 找不到 adapter | 先 `./scripts/train.sh <persona>`                  |
| 端口占用        | `./scripts/free_port.sh 8080` / `3000`            |
| 请求超时        | 等待模型加载；关闭占内存应用                                    |
| 提取数据很少      | 检查 `--source` 路径与 GBK 编码                          |
| 人格混乱        | 前端选项与 `serve.sh` 参数保持一致                           |


Web 可调参数：**温度** 0.7、**最大 tokens** 512。

---

## 六、打包说明

```
extract_multi_personas.py, config/, scripts/, web/, requirements.txt
data/          # 可选，便于直接训练
adapters/      # 可选，便于直接 serve
README.md
```


| 内容   | 路径                                 | 大小     |
| ---- | ---------------------------------- | ------ |
| 基座模型 | `models/Qwen2.5-7B-Instruct-4bit/` | ~4 GB  |
| 小说原文 | `庆余年.txt`                          | ~5 MB（ |


### 6.3 使用最短路径（已含基座 + adapter）

```bash
pip install -r requirements.txt
./scripts/serve.sh fanxian    # 终端 1
./scripts/web.sh              # 终端 2
# http://127.0.0.1:3000
```

需自备：Python 3.10+、macOS Apple Silicon、mlx-lm（`pip install -r requirements.txt`）。

---

## 七、产物对照


| 路径                                 | 内容      |
| ---------------------------------- | ------- |
| `data/{persona}/train.jsonl`       | 训练集     |
| `data/{persona}/valid.jsonl`       | 验证集     |
| `adapters/{persona}/`              | LoRA 权重 |
| `models/Qwen2.5-7B-Instruct-4bit/` | 基座模型    |
| `extract_multi_personas.py`        | 数据提取入口  |


